#ifndef EXCLUSIVE_RELATIONS_H
#define EXCLUSIVE_RELATIONS_H

/* This generated file contains includes for project dependencies */
#include "exclusive_relations/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

