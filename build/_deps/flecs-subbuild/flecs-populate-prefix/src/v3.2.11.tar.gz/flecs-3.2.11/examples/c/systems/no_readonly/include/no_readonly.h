#ifndef NO_READONLY_H
#define NO_READONLY_H

/* This generated file contains includes for project dependencies */
#include "no_readonly/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

