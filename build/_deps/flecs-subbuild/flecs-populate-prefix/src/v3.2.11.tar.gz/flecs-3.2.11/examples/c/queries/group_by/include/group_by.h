#ifndef GROUP_BY_H
#define GROUP_BY_H

/* This generated file contains includes for project dependencies */
#include "group_by/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

