#ifndef ENQUEUE_EVENT_H
#define ENQUEUE_EVENT_H

/* This generated file contains includes for project dependencies */
#include "enqueue_event/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

