#ifndef CUSTOM_RUNNER_H
#define CUSTOM_RUNNER_H

/* This generated file contains includes for project dependencies */
#include "custom_runner/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

