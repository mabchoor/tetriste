#ifndef AUTO_DEFINE_NESTED_STRUCT_H
#define AUTO_DEFINE_NESTED_STRUCT_H

/* This generated file contains includes for project dependencies */
#include "auto_define_nested_struct/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

