#ifndef YIELD_EXISTING_H
#define YIELD_EXISTING_H

/* This generated file contains includes for project dependencies */
#include "yield_existing/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

