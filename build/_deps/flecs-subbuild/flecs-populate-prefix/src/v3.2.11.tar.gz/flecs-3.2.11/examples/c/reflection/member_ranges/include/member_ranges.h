#ifndef MEMBER_RANGES_H
#define MEMBER_RANGES_H

/* This generated file contains includes for project dependencies */
#include "member_ranges/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

