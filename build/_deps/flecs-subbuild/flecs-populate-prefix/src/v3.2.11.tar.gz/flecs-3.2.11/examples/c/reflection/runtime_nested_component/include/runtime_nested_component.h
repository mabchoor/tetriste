#ifndef RUNTIME_NESTED_COMPONENT_H
#define RUNTIME_NESTED_COMPONENT_H

/* This generated file contains includes for project dependencies */
#include "runtime_nested_component/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

