#ifndef GROUP_BY_CUSTOM_H
#define GROUP_BY_CUSTOM_H

/* This generated file contains includes for project dependencies */
#include "group_by_custom/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

