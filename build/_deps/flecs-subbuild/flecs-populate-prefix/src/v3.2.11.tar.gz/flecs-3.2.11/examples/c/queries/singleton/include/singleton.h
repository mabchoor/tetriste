#ifndef SINGLETON_H
#define SINGLETON_H

/* This generated file contains includes for project dependencies */
#include "singleton/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

