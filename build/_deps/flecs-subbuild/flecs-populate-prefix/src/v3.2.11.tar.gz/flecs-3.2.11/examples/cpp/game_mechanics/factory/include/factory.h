#ifndef FACTORY_H
#define FACTORY_H

/* This generated file contains includes for project dependencies */
#include "factory/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

