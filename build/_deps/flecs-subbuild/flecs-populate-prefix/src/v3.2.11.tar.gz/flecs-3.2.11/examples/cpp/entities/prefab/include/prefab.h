#ifndef PREFAB_H
#define PREFAB_H

/* This generated file contains includes for project dependencies */
#include "prefab/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

