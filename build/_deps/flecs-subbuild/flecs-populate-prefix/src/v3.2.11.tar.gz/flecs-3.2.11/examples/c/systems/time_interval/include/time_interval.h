#ifndef TIME_INTERVAL_H
#define TIME_INTERVAL_H

/* This generated file contains includes for project dependencies */
#include "time_interval/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

