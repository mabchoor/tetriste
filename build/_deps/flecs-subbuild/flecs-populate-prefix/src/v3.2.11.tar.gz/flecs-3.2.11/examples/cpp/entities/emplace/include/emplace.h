#ifndef EMPLACE_H
#define EMPLACE_H

/* This generated file contains includes for project dependencies */
#include "emplace/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

