#ifndef TYPED_PREFABS_H
#define TYPED_PREFABS_H

/* This generated file contains includes for project dependencies */
#include "typed_prefabs/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

