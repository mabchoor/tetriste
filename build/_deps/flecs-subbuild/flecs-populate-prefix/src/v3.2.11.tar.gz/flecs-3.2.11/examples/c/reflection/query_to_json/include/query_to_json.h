#ifndef QUERY_TO_JSON_H
#define QUERY_TO_JSON_H

/* This generated file contains includes for project dependencies */
#include "query_to_json/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

